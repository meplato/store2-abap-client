Meplato Store API SAP Transports for SAP ECC 6.0 and higher

Please import in the following transport requests (mark the requests and import them at once):

1. R60K900059
2. R60K900443
3. R60K900594

4. R60K900596 - additional task containing deleted objects - for systems into which earlier versions of the standard transport have been imported